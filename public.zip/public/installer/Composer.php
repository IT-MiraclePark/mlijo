<?php

$data = array();
$data['install'] = 0;

echo json_encode($data);