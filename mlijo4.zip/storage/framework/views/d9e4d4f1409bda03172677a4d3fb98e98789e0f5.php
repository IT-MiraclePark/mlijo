<div class="control-group">
    <label><?php echo e(__('velocity::app.admin.meta-data.slider-path')); ?></label>

    <input
        type="text"
        class="control"
        name="slider_path"
        value="<?php echo e((isset($slider) && $slider->slider_path) ? $slider->slider_path : ''); ?>" />
</div><?php /**PATH D:\xampp\htdocs\bagisto\packages\Webkul\Velocity\src/resources/views/admin/settings/sliders/velocity-slider.blade.php ENDPATH**/ ?>