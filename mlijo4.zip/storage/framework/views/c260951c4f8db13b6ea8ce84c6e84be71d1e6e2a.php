<?php echo view_render_event('bagisto.shop.products.view.stock.before', ['product' => $product]); ?>


<div class="col-12 availability">
    <button
        type="button"
        class="<?php echo e(! $product->haveSufficientQuantity(1) ? '' : 'active'); ?> disable-box-shadow">
        <?php echo e($product->haveSufficientQuantity(1) ? __('shop::app.products.in-stock') : __('shop::app.products.out-of-stock')); ?>

    </button>
</div>

<?php echo view_render_event('bagisto.shop.products.view.stock.after', ['product' => $product]); ?><?php /**PATH D:\xampp\htdocs\bagisto/resources/themes/velocity/views/products/view/stock.blade.php ENDPATH**/ ?>