<div class="container-fluid product-policy-container no-padding">
    <div class="row">
        <?php echo $velocityMetaData->product_policy; ?>

    </div>
</div>
<?php /**PATH D:\xampp\htdocs\bagisto/resources/themes/velocity/views/home/product-policy.blade.php ENDPATH**/ ?>