<div class="row footer-statics col-12 no-margin">
    <?php echo $__env->make('velocity::layouts.footer.footer-links.footer-left', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('velocity::layouts.footer.footer-links.footer-middle', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('velocity::layouts.footer.footer-links.footer-right', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<?php /**PATH D:\xampp\htdocs\bagisto/resources/themes/velocity/views/layouts/footer/footer-links.blade.php ENDPATH**/ ?>