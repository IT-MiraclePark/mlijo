<a href="{{ route('shop.home.index') }}">
    <img
        src="{{ asset('themes/velocity/assets/images/static/logo-text-white.png') }}"
        class="logo full-img" />
</a>